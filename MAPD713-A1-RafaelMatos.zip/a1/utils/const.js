module.exports.DATE_SEPARATOR = '.'
module.exports.HOUR_SEPARATOR = ':'
module.exports.SEPARATOR = '-'
